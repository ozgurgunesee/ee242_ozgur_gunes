# STM32-base F3 template

This is a project template for using the STM32-base project with a STM32F3 series device. See the [STM32-base project](https://github.com/STM32-base/STM32-base) for more information on how to get started with this template.

**Note:** If you want to report an issue for this template, please report it on the [STM32-base project](https://github.com/STM32-base/STM32-base).
